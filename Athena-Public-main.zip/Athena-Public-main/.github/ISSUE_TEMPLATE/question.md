---
name: Question
about: Ask a question about using Project Athena
title: '[QUESTION] '
labels: question
assignees: ''
---

## Your Question

What would you like to know?

## Context

- What are you trying to accomplish?
- What have you already tried?

## Environment (if relevant)

- OS:
- AI Model:
- Athena Version:
