"""
athena.core
===========

Core primitives for the Athena Operating System.
Includes Identity, Boot logic, and base Protocol definitions.
"""
