"""Athena Generators - Protocol, Case Study, Graph generation tools."""
