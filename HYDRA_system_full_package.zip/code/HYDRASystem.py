# Full HYDRASystem code goes here
class HYDRASystem:
    def __init__(self):
        pass
