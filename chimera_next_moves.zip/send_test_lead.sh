#!/bin/bash
WEBHOOK=${WEBHOOK_URL:-http://localhost:8080/webhook/lead}
curl -X POST $WEBHOOK -H 'Content-Type: application/json' -d '{ "name":"Test Lead","email":"test@lead.example","company":"ExampleCo" }'
