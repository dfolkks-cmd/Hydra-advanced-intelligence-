
Chimera Next Moves Package
Generated: 2025-11-28T03:19:26.529657Z

Contains:
- n8n_full_workflow.json
- notion_bootstrap.py
- 30_day_cadence.csv + templates
- deploy_docker_compose.yml
- k8s_deploy.yaml
- send_test_lead.sh
- deploy_instructions.txt

Next recommended actions:
- Seed a small list of 200 leads, run through pipeline, tune scoring thresholds.
- Start with 2 worker replicas, monitor Redis queue and scale to 10 if growth.
- Use test SMTP before live sends. Warm up domains slowly.
