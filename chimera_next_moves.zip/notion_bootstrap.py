# notion_bootstrap.py
# Usage: set NOTION_TOKEN and run: python notion_bootstrap.py
import os, json
from notion_client import Client

NOTION_TOKEN = os.getenv('NOTION_TOKEN')
if not NOTION_TOKEN:
    print('Set NOTION_TOKEN in env')
    exit(1)

notion = Client(auth=NOTION_TOKEN)

def create_database(parent_page_id, title):
    db_payload = {
        "parent": {"type":"page_id", "page_id": parent_page_id} if parent_page_id else {"type":"workspace"},
        "title": [{"type":"text","text":{"content":title}}],
        "properties": {
            "Name":{"title":{}},
            "Company":{"rich_text":{}},
            "Email":{"email":{}},
            "Source":{"select":{"options":[{"name":"webhook"},{"name":"scrape"},{"name":"manual"}]}},
            "Score":{"number":{}},
            "Stage":{"select":{"options":[{"name":"New"},{"name":"Contacted"},{"name":"Qualified"},{"name":"Proposal"},{"name":"Onboarding"},{"name":"Client"}]}},
            "Assigned Agent":{"people":{}},
            "Next Action":{"date":{}},
            "Notes":{"rich_text":{}}
        }
    }
    db = notion.databases.create(**db_payload)
    return db

if __name__ == '__main__':
    parent = os.getenv('NOTION_PARENT_PAGE_ID') or None
    title = 'Leads - Chimera Revenue Engine'
    db = create_database(parent, title)
    print('Created DB ID:', db['id'])
    # seed sample page
    notion.pages.create(parent={'database_id': db['id']}, properties={
        'Name': {'title':[{'text':{'content':'Jane Doe'}}]},
        'Company': {'rich_text':[{'text':{'content':'Acme Inc'}}]},
        'Email': {'email':'jane@acme.example'}
    })
    print('Seeded sample lead')
