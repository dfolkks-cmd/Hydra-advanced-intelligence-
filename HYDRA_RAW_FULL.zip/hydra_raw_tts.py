import pyttsx3, random, yaml

with open("hydra_raw_personality.yaml") as f:
    personality = yaml.safe_load(f)["personality"]

engine = pyttsx3.init()
engine.setProperty('rate', int(200 * personality['prosody']['rate']))
engine.setProperty('pitch', int(100 * personality['prosody']['pitch']))

def speak(category="greeting"):
    phrase = random.choice(personality["phrases"].get(category, ["Ready."]))
    engine.say(phrase)
    engine.runAndWait() 

if __name__ == "__main__":
    speak("greeting")
    speak("motivational")
    speak("status")