import pyttsx3, yaml, sys

with open("hydra_raw_personality.yaml") as f:
    personality = yaml.safe_load(f)["personality"]

engine = pyttsx3.init()
engine.setProperty('rate', int(200 * personality['prosody']['rate']))
engine.setProperty('pitch', int(100 * personality['prosody']['pitch']))

def speak(text):
    phrase = f"MOTHERFUCKER! {text}!"
    engine.say(phrase)
    engine.runAndWait()

if len(sys.argv) > 1:
    speak(sys.argv[1])
else:
    speak("No input provided. Say it again, motherfucker.")