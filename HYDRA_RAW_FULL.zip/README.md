# HYDRA Raw Mode AI Personality

## Deployment on iPhone
1. Install Pythonista or Pyto.
2. Copy `HYDRA_RAW_FULL` folder to the app's script directory.
3. Test `hydra_raw_tts.py` for basic voice output.
4. Test `hydra_raw_interactive.py` for dynamic input.
5. Optional Shortcut:
   - Shortcut → Run Script → select `hydra_shortcut_trigger.py`
   - Add input variable for text → speak HYDRA style
   - Siri command: "Hey Siri, HYDRA mode"
6. Optional Back Tap trigger for instant motivational hit.
7. Modify `hydra_raw_personality.yaml` to expand phrases and categories.

## Features
- Uncensored, streetwise speech
- Dynamic input via terminal or Shortcut
- Siri/Home Screen triggers
- Prosody controls for commanding tone
- Multiple phrase categories: greeting, motivational, status, fallback
- Fully safe — read-only TTS only