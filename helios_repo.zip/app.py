# app.py minimal
import os, logging, uuid
from fastapi import FastAPI, HTTPException, Request, Depends
from pydantic import BaseModel, Field
from typing import List, Optional
from db import SessionLocal, init_db
from models import CampaignRecord, IdempotencyKey
from google_ads_integration import create_full_search_campaign

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("helios.app")
app = FastAPI()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./helios_dev.db")
init_db(DATABASE_URL)

def get_db():
    db = SessionLocal(DATABASE_URL)
    try:
        yield db
    finally:
        db.close()

class CreateCampaignRequest(BaseModel):
    customer_id: str
    campaign_name: str
    daily_budget_usd: float
    keywords: List[str]
    final_url: str
    sandbox: Optional[bool] = True
    idempotency_key: Optional[str] = None

@app.post("/campaigns/create")
def create_campaign(payload: CreateCampaignRequest, request: Request, db=Depends(get_db)):
    id_key = payload.idempotency_key or request.headers.get("Idempotency-Key") or str(uuid.uuid4())
    # simplified for scaffold: call integration and persist minimal record
    resources = create_full_search_campaign(payload.customer_id, payload.campaign_name, payload.daily_budget_usd, payload.keywords, payload.final_url, sandbox=payload.sandbox)
    return {"resources": resources}
