from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Float, Text, TIMESTAMP, func
Base = declarative_base()
class CampaignRecord(Base):
    __tablename__ = "campaigns"
    id = Column(Integer, primary_key=True, index=True)
    campaign_name = Column(String(255))
class IdempotencyKey(Base):
    __tablename__ = "idempotency_keys"
    key = Column(String(128), primary_key=True)
