from fastapi.testclient import TestClient
from app import app
def test_smoke():
    client = TestClient(app)
    payload = {
        "customer_id": "test",
        "campaign_name": "smoke",
        "daily_budget_usd": 1.0,
        "keywords": ["a"],
        "final_url": "https://example.com",
        "sandbox": True,
        "idempotency_key": "smoke-1"
    }
    r = client.post("/campaigns/create", json=payload)
    assert r.status_code == 200
    data = r.json()
    assert "resources" in data
