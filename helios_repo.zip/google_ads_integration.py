# stub google_ads_integration for scaffold (does not call real API)
def create_full_search_campaign(customer_id, campaign_name, daily_budget_usd, keywords, final_url, sandbox=True):
    # return mock resource names for testing
    return {
        "budget_resource": f"budget/{campaign_name}",
        "campaign_resource": f"campaign/{campaign_name}",
        "ad_group_resource": f"adgroup/{campaign_name}",
        "rsa_resource": f"rsa/{campaign_name}"
    }
